package com.mt.movies.Movies.REST;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MainController {

    @RequestMapping(value = "/index")
    public String index() {
        return "index";
    }

    @RequestMapping(value = "/file")
    public String file() {
        return "file";
    }

    @RequestMapping(value = "/director")
    public String director() {
        return "director";
    }



    //Films Controller
    @RequestMapping(value = "/allfilms")
    public String allfilms() {
        return "allfilms";
    }

    @RequestMapping(value = "/addfilm")
    public String addfilm() {
        return "addfilm";
    }

    @RequestMapping(value = "/deletefilm")
    public String deletefilm() {
        return "deletefilm";
    }

    @RequestMapping(value = "/updatefilm")
    public String updatefilm() {
        return "updatefilm";
    }

    @RequestMapping(value = "/singlefilm")
    public String singlefilm() {
        return "singlefilm";
    }

    //Director Controller

}
